<?php
//Silence is golden 